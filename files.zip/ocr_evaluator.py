"""
OCR Evaluation Framework - single-class edition.

Compares ground-truth text files against the outputs of one or more OCR
models (mirrored directory trees) and produces a multi-sheet Excel report.
All behaviour is driven by a YAML configuration file.

Usage:
    python ocr_evaluator.py --config config.yaml

or programmatically:

    from ocr_evaluator import OCREvaluator
    report_path = OCREvaluator("config.yaml").run()

Adding a new metric:
    1. Write a method  ``_metric_<name>(self, gt: str, ocr: str) -> float``.
    2. Add ``<name>`` to the ``metrics`` list in config.yaml.
    Nothing else changes - the metric flows through every report sheet.
"""

from __future__ import annotations

import argparse
import difflib
import logging
import re
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import yaml
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger("ocr_eval")


class OCREvaluator:
    """End-to-end OCR quality evaluation: pair files, score, and report.

    The evaluator recursively walks the ground-truth directory, locates each
    file's OCR counterpart under ``<target_dir>/<model>/<same relative path>``
    for every configured model, computes the configured metrics on normalised
    text, and writes a formatted Excel report with detailed results, summary
    statistics, a model comparison, and metric distributions.
    """

    # Metric names where lower values indicate better OCR quality.
    LOWER_IS_BETTER = {"cer", "wer"}
    # Metric names where "closest to 1.0" is best (for comparison highlighting).
    CLOSEST_TO_ONE = {"length_ratio"}

    # ------------------------------------------------------------------ #
    # Construction / configuration
    # ------------------------------------------------------------------ #

    def __init__(self, config_path: str | Path):
        with open(config_path, "r", encoding="utf-8") as handle:
            cfg = yaml.safe_load(handle)

        paths, files = cfg["paths"], cfg.get("files", {})
        report, norm = cfg.get("report", {}), cfg.get("normalization", {})

        self.source_dir = Path(paths["source_dir"])
        self.target_dir = Path(paths["target_dir"])
        self.output_report = Path(paths["output_report"])
        self.models: List[str] = list(cfg["models"])

        self.gt_extensions = [e.lower() for e in files.get("ground_truth_extensions", [".txt"])]
        self.ocr_extensions = [e.lower() for e in files.get("ocr_output_extensions", [".txt"])]
        self.encoding = files.get("encoding", "utf-8")

        self.norm_options = norm
        self.metric_names: List[str] = list(cfg.get("metrics", []))
        self.summary_stats = report.get("summary_statistics",
                                        ["mean", "min", "max", "median", "std"])
        self.distribution_bins = int(report.get("distribution_bins", 10))
        self.decimals = int(report.get("decimal_places", 4))

        logging.basicConfig(
            level=getattr(logging, cfg.get("logging_level", "INFO").upper(), logging.INFO),
            format="%(asctime)s  %(levelname)-8s %(message)s",
        )
        self._validate()

    def _validate(self) -> None:
        if not self.models:
            raise ValueError("Config must list at least one OCR model.")
        unknown = [m for m in self.metric_names if not hasattr(self, f"_metric_{m}")]
        if unknown:
            available = sorted(a[len("_metric_"):] for a in dir(self) if a.startswith("_metric_"))
            raise ValueError(f"Unknown metric(s) {unknown}. Available: {available}")
        if not self.metric_names:
            raise ValueError("Config must enable at least one metric.")

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def run(self) -> Path:
        """Evaluate every (model, file) pair and write the Excel report."""
        if not self.source_dir.is_dir():
            raise FileNotFoundError(f"Source directory not found: {self.source_dir}")
        if not self.target_dir.is_dir():
            raise FileNotFoundError(f"Target directory not found: {self.target_dir}")

        detailed = self._evaluate_all()
        self._write_report(detailed)
        logger.info("Report written to %s", self.output_report)
        return self.output_report

    # ------------------------------------------------------------------ #
    # Evaluation
    # ------------------------------------------------------------------ #

    def _evaluate_all(self) -> pd.DataFrame:
        """One row per (model, file): status + all metric values."""
        gt_ext = set(self.gt_extensions)
        gt_files = [p for p in sorted(self.source_dir.rglob("*"))
                    if p.is_file() and p.suffix.lower() in gt_ext]
        logger.info("Found %d ground-truth files in %s", len(gt_files), self.source_dir)

        rows: List[Dict] = []
        for gt_path in gt_files:
            relative = gt_path.relative_to(self.source_dir)
            for model in self.models:
                rows.append(self._evaluate_pair(model, relative, gt_path))

        ok = sum(1 for r in rows if r["status"] == "ok")
        logger.info("Evaluated %d pairs (%d ok, %d problematic)", len(rows), ok, len(rows) - ok)
        return pd.DataFrame(rows).sort_values(["model", "file"]).reset_index(drop=True)

    def _evaluate_pair(self, model: str, relative: Path, gt_path: Path) -> Dict:
        row: Dict = {"model": model, "file": str(relative), "status": "ok"}
        ocr_path = self._locate_ocr_file(model, relative)
        if ocr_path is None:
            logger.warning("[%s] Missing OCR output for %s", model, relative)
            row["status"] = "missing_ocr"
            return row
        try:
            gt = self._normalize(gt_path.read_text(encoding=self.encoding, errors="replace"))
            ocr = self._normalize(ocr_path.read_text(encoding=self.encoding, errors="replace"))
        except OSError as error:
            logger.error("Read error for %s: %s", relative, error)
            row["status"] = "read_error"
            return row

        for name in self.metric_names:
            value = getattr(self, f"_metric_{name}")(gt, ocr)
            row[name] = round(value, self.decimals) if np.isfinite(value) else value
        return row

    def _locate_ocr_file(self, model: str, relative: Path) -> Optional[Path]:
        """Same relative path and stem as the ground truth; extensions tried in order."""
        base = self.target_dir / model / relative
        for extension in self.ocr_extensions:
            candidate = base.with_suffix(extension)
            if candidate.is_file():
                return candidate
        return None

    # ------------------------------------------------------------------ #
    # Text normalisation
    # ------------------------------------------------------------------ #

    def _normalize(self, text: str) -> str:
        opts = self.norm_options
        if opts.get("unicode_nfkc", True):
            text = unicodedata.normalize("NFKC", text)
        if opts.get("lowercase", True):
            text = text.lower()
        if opts.get("remove_punctuation", False):
            text = re.sub(r"[^\w\s]", " ", text)
        if opts.get("collapse_whitespace", True):
            text = re.sub(r"\s+", " ", text)
        if opts.get("strip", True):
            text = text.strip()
        return text

    # ------------------------------------------------------------------ #
    # Metrics  (add a _metric_<name> method + config entry to extend)
    # ------------------------------------------------------------------ #

    @staticmethod
    def _levenshtein(ref: Sequence, hyp: Sequence) -> int:
        """Edit distance via a memory-efficient two-row DP. Works on strings
        (character level) and token lists (word level)."""
        if ref == hyp:
            return 0
        if not ref or not hyp:
            return len(ref) or len(hyp)
        if len(hyp) < len(ref):
            ref, hyp = hyp, ref
        previous = list(range(len(ref) + 1))
        for i, h in enumerate(hyp, start=1):
            current = [i] + [0] * len(ref)
            for j, r in enumerate(ref, start=1):
                current[j] = min(previous[j - 1] + (h != r),  # substitution
                                 current[j - 1] + 1,          # insertion
                                 previous[j] + 1)             # deletion
            previous = current
        return previous[-1]

    def _metric_cer(self, gt: str, ocr: str) -> float:
        """Character Error Rate: edit_distance(chars) / len(gt). Lower is better."""
        if not gt:
            return 0.0 if not ocr else 1.0
        return self._levenshtein(gt, ocr) / len(gt)

    def _metric_wer(self, gt: str, ocr: str) -> float:
        """Word Error Rate: edit_distance(words) / word count of gt. Lower is better."""
        ref, hyp = gt.split(), ocr.split()
        if not ref:
            return 0.0 if not hyp else 1.0
        return self._levenshtein(ref, hyp) / len(ref)

    def _metric_char_accuracy(self, gt: str, ocr: str) -> float:
        """max(0, 1 - CER), bounded to [0, 1]. Higher is better."""
        return max(0.0, 1.0 - self._metric_cer(gt, ocr))

    def _metric_sequence_similarity(self, gt: str, ocr: str) -> float:
        """difflib.SequenceMatcher character-level ratio in [0, 1]. Higher is better."""
        if not gt and not ocr:
            return 1.0
        return difflib.SequenceMatcher(None, gt, ocr).ratio()

    def _metric_word_precision(self, gt: str, ocr: str) -> float:
        """Fraction of OCR words present in the ground truth (multiset overlap)."""
        tp, n_ocr, _ = self._word_overlap(gt, ocr)
        return tp / n_ocr if n_ocr else (1.0 if not gt.split() else 0.0)

    def _metric_word_recall(self, gt: str, ocr: str) -> float:
        """Fraction of ground-truth words recovered by the OCR (multiset overlap)."""
        tp, _, n_gt = self._word_overlap(gt, ocr)
        return tp / n_gt if n_gt else (1.0 if not ocr.split() else 0.0)

    def _metric_word_f1(self, gt: str, ocr: str) -> float:
        """Harmonic mean of word precision and recall."""
        p, r = self._metric_word_precision(gt, ocr), self._metric_word_recall(gt, ocr)
        return 2 * p * r / (p + r) if p + r else 0.0

    def _metric_length_ratio(self, gt: str, ocr: str) -> float:
        """len(ocr) / len(gt). ~1.0 ideal; <1 dropped text, >1 hallucinated text."""
        if not gt:
            return 1.0 if not ocr else float("inf")
        return len(ocr) / len(gt)

    @staticmethod
    def _word_overlap(gt: str, ocr: str) -> tuple:
        gt_counts, ocr_counts = Counter(gt.split()), Counter(ocr.split())
        tp = sum((gt_counts & ocr_counts).values())
        return tp, sum(ocr_counts.values()), sum(gt_counts.values())

    # ------------------------------------------------------------------ #
    # Excel report
    # ------------------------------------------------------------------ #

    def _write_report(self, detailed: pd.DataFrame) -> None:
        summary = self._summary_frame(detailed)
        comparison = self._comparison_frame(detailed)
        distributions = self._distribution_frame(detailed)

        self.output_report.parent.mkdir(parents=True, exist_ok=True)
        with pd.ExcelWriter(self.output_report, engine="openpyxl") as writer:
            detailed.to_excel(writer, sheet_name="Detailed Results", index=False)
            summary.to_excel(writer, sheet_name="Summary Statistics", index=False)
            comparison.to_excel(writer, sheet_name="Model Comparison", index=False)
            distributions.to_excel(writer, sheet_name="Distributions", index=False)
            for sheet in writer.sheets.values():
                self._style_sheet(sheet)
            self._highlight_best(writer.sheets["Model Comparison"], comparison)

    def _summary_frame(self, detailed: pd.DataFrame) -> pd.DataFrame:
        """Per model per metric: configured statistics + evaluated/missing counts."""
        rows = []
        for model, group in detailed.groupby("model", sort=True):
            ok = group[group["status"] == "ok"]
            for metric in self.metric_names:
                values = pd.to_numeric(ok.get(metric), errors="coerce").dropna()
                row: Dict = {"model": model, "metric": metric,
                             "files_evaluated": len(ok),
                             "files_missing_or_failed": len(group) - len(ok)}
                for stat in self.summary_stats:
                    row[stat] = (round(float(getattr(values, stat)()), self.decimals)
                                 if len(values) else None)
                rows.append(row)
        return pd.DataFrame(rows)

    def _comparison_frame(self, detailed: pd.DataFrame) -> pd.DataFrame:
        """Models as rows, metric means as columns - the at-a-glance view."""
        ok = detailed[detailed["status"] == "ok"]
        counts = detailed.groupby("model")["status"].agg(
            files_total="count",
            files_evaluated=lambda s: int((s == "ok").sum()),
        ).reset_index()
        if ok.empty:
            return counts
        means = (ok.groupby("model")[self.metric_names].mean(numeric_only=True)
                 .round(self.decimals).reset_index())
        return counts.merge(means, on="model", how="left")

    def _distribution_frame(self, detailed: pd.DataFrame) -> pd.DataFrame:
        """Histogram counts per metric per model, binned over a shared global
        range so distributions are directly comparable across models."""
        ok = detailed[detailed["status"] == "ok"]
        rows = []
        for metric in self.metric_names:
            values_all = pd.to_numeric(ok.get(metric), errors="coerce")
            finite = values_all[np.isfinite(values_all)]
            if finite.empty:
                continue
            low, high = float(finite.min()), float(finite.max())
            if low == high:  # avoid zero-width bins
                low, high = low - 0.5, high + 0.5
            edges = np.linspace(low, high, self.distribution_bins + 1)
            for model, group in ok.groupby("model"):
                values = pd.to_numeric(group[metric], errors="coerce")
                counts, _ = np.histogram(values[np.isfinite(values)], bins=edges)
                rows.extend({"metric": metric, "model": model,
                             "bin_start": round(float(edges[i]), self.decimals),
                             "bin_end": round(float(edges[i + 1]), self.decimals),
                             "count": int(c)}
                            for i, c in enumerate(counts))
        return pd.DataFrame(rows)

    # -- styling ------------------------------------------------------- #

    @staticmethod
    def _style_sheet(sheet) -> None:
        """Navy header, Arial body, thin borders, auto widths, frozen header row."""
        header_fill = PatternFill("solid", fgColor="1F4E79")
        header_font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
        body_font = Font(name="Arial", size=10)
        border = Border(*[Side(style="thin", color="D9D9D9")] * 4)

        for cell in sheet[1]:
            cell.fill, cell.font = header_fill, header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.font, cell.border = body_font, border
        for column in sheet.columns:
            letter = get_column_letter(column[0].column)
            longest = max((len(str(c.value)) for c in column if c.value is not None), default=8)
            sheet.column_dimensions[letter].width = min(max(longest + 2, 10), 60)
        sheet.freeze_panes = "A2"

    def _highlight_best(self, sheet, comparison: pd.DataFrame) -> None:
        """Highlight the best model per metric column (direction-aware)."""
        best_fill = PatternFill("solid", fgColor="C6EFCE")
        for col_idx, column in enumerate(comparison.columns, start=1):
            if column not in self.metric_names:
                continue
            values = pd.to_numeric(comparison[column], errors="coerce")
            if values.dropna().empty:
                continue
            if column in self.CLOSEST_TO_ONE:
                best_row = (values - 1.0).abs().idxmin()
            elif column in self.LOWER_IS_BETTER:
                best_row = values.idxmin()
            else:
                best_row = values.idxmax()
            sheet.cell(row=int(best_row) + 2, column=col_idx).fill = best_fill


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate OCR outputs against ground truth.")
    parser.add_argument("--config", default="config.yaml", help="Path to the YAML config file.")
    args = parser.parse_args()
    report_path = OCREvaluator(args.config).run()
    print(f"\nDone. Report: {report_path}")


if __name__ == "__main__":
    main()
