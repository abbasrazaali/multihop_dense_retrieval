# mdx-pipeline — MarkItDown Extraction Pipeline

A production-grade, high-throughput document → Markdown extraction pipeline built on [Microsoft MarkItDown](https://github.com/microsoft/markitdown), extended with:

- **Structure-aware PDF extraction** (headings, paragraphs, lists, tables, captions, headers/footers, footnotes, figure/table titles, page boundaries, column-aware reading order) via a custom `HybridPdfConverter` that replaces MarkItDown's built-in PDF converter at higher priority.
- **Intelligent OCR routing** — every PDF page is classified `DIGITAL / SCANNED / MIXED / EMPTY`; **Mistral OCR is invoked only for scanned pages and images that actually contain text**, so digitally generated text never wastes an OCR call.
- **Mistral OCR integration** with client-side rate limiting, exponential-backoff retries, page-level confidence handling, content-addressed caching, and two submission modes (`subset_pdf` for fewest round trips, `per_page_image` for maximal cache granularity).
- **VLM figure descriptions** — images, charts, graphs, diagrams and infographics are described in **2–5 analytical paragraphs** using *your* prompt, model and credentials (any OpenAI-compatible endpoint or the Mistral chat API). A minimum-paragraph guard retries thin responses once.
- **Batch engine** — bounded thread pools at the document and page level, token-bucket rate limiting per external service, waves (`batch_size`) for bounded memory, idempotent re-runs, quarantine of failed inputs, per-document metadata JSON with timings and routing decisions.
- **One comprehensive YAML config** (`config/pipeline.yaml`) covering OCR, routing thresholds, workers, batching, image preprocessing, Markdown element toggles, figure/table settings, IO paths, logging, error policies, retries, timeouts, caching and model selection — with `${ENV}` interpolation and `MDX__SECTION__KEY` environment overrides.

All non-PDF formats supported by MarkItDown (DOCX, PPTX, XLSX, HTML, EPUB, …) continue to work untouched; standalone image files get the same OCR-routing + description treatment as embedded figures.

---

## Installation

```bash
pip install -e .                      # from this repo
# optional deskew support:
pip install -e ".[preprocessing]"
```

Requires Python ≥ 3.10. Dependencies: `markitdown[all]`, `pymupdf`, `mistralai`, `pydantic`, `PyYAML`, `requests`, `Pillow`.

## Credentials

Never put keys in the YAML. Export them:

```bash
export MISTRAL_API_KEY="..."          # Mistral OCR
export VLM_API_KEY="..."              # figure-description model (defaults to MISTRAL_API_KEY)
export VLM_BASE_URL="https://api.mistral.ai/v1"   # or your local vLLM endpoint
export VLM_MODEL="mistral-medium-2508"
```

Any config value can also be overridden per-deployment without editing the file:

```bash
export MDX__PERFORMANCE__DOC_WORKERS=8
export MDX__OCR__SUBMISSION_MODE=per_page_image
export MDX__MARKDOWN__ELEMENTS__FOOTERS=true
```

## Usage

```bash
# batch: process everything under io.input_dir
mdx -c config/pipeline.yaml run
mdx -c config/pipeline.yaml run --input ./docs --output ./out

# single file (markdown to stdout or -o file)
mdx -c config/pipeline.yaml one report.pdf -o report.md

# dry-run: show per-page OCR routing decisions without any API calls
mdx -c config/pipeline.yaml routes report.pdf
```

Programmatic:

```python
from mdx_pipeline import PipelineConfig, BatchProcessor, build_markitdown

cfg = PipelineConfig.load("config/pipeline.yaml")

# batch
stats = BatchProcessor(cfg).run()

# or use the customized MarkItDown instance directly
md = build_markitdown(cfg)
result = md.convert("report.pdf")
print(result.markdown)
```

As a MarkItDown plugin (entry point `markitdown.plugin` is declared, so any MarkItDown instance can pick the converters up):

```python
from markitdown import MarkItDown
md = MarkItDown(enable_plugins=True)   # reads MDX_CONFIG env var for the YAML path
```

## Architecture

```
input files ──► BatchProcessor (doc_workers threads, waves of batch_size)
                   │
                   ▼
             MarkItDown (built-ins + overrides at priority −10)
                   │
      ┌────────────┼──────────────────────────────┐
      ▼            ▼                              ▼
HybridPdfConverter  ImageOcrConverter        built-in converters
      │                                       (docx/pptx/xlsx/html…)
      ▼
 page classifier (routing.py)
  DIGITAL ─► PyMuPDF layout analysis: headings (font stats / PDF outline),
             lists, tables (find_tables), captions, headers/footers
             (cross-page repetition), footnotes, column-aware reading order
  SCANNED ─► MistralOcrClient (subset_pdf | per_page_image, cached, throttled)
  MIXED   ─► native text + per-image routing:
               text-likelihood heuristic ─► Mistral OCR (text images only)
               all sizeable figures      ─► FigureDescriber (2–5 paragraphs)
      │
      ▼
 MarkdownRenderer (element toggles, page boundaries, front matter)
      │
      ▼
 output/*.md  +  output/*.meta.json (timings, per-page routing)
```

### OCR routing rules

| Page condition | Class | Action |
|---|---|---|
| ≥ `min_chars_digital` chars, image area < `mixed_image_area_threshold` | DIGITAL | native extraction only |
| ≥ `min_chars_digital` chars, image area ≥ threshold | MIXED | native text + image routing |
| < `min_chars_digital` chars, image area ≥ `image_area_threshold` (or any imagery) | SCANNED | Mistral OCR |
| no text, no imagery | EMPTY | page-boundary marker only |

Embedded images are OCR'd only when `image_ocr_mode` allows it: `auto` (default) applies a cheap local heuristic (edge-transition structure, line periodicity, palette poverty — no model calls) and OCRs only images scoring ≥ `text_likelihood_threshold`; `always`/`never` do what they say. Tiny decorations are filtered by `image_min_edge_px` / `image_min_area_ratio`, and identical images are deduplicated by SHA-256.

### Output structure

Per document: front matter (source, page count, hash, scanned-page count), optional `# Title`, `<!-- page: N -->` boundaries, `#`–`####` headings, paragraphs, `-`/`1.` lists, GitHub tables with bold **Table N** titles, *captions*, `[^n]:` footnotes, and figure blocks:

```markdown
**Figure 3: Monthly consumption trend**

> *Figure description:* The bar chart shows chilled-water consumption across …
> (2–5 paragraphs)

> *Text extracted from figure:*  (only when the image was routed to OCR)
```

Every element type can be switched off independently under `markdown.elements`, and headers/footers are dropped by default (set `headers: true` / `footers: true` to keep them tagged).

## Performance tuning

| Goal | Knobs |
|---|---|
| Throughput | `performance.doc_workers` (docs in parallel), `performance.page_workers` (OCR/VLM calls per doc), `ocr.requests_per_second`, `figure_description.requests_per_second` |
| Latency per doc | `ocr.submission_mode: subset_pdf` (one request per scanned run), `figure_description.max_image_dim_px` (smaller uploads) |
| Memory | `performance.batch_size` (wave size), `performance.low_memory_mode`, pixmaps are released eagerly |
| Cost | caching (`cache.*` — identical pages/images/prompts are never re-billed), routing thresholds, `routing.dedupe_images` |
| Accuracy | `ocr.render_dpi`, `ocr.min_confidence` (flags low-confidence pages), `image_preprocessing.*` (grayscale/denoise/binarize/upscale) |

Rate limiters are token buckets shared across all workers, so raising worker counts never exceeds your API quota — requests queue instead of failing.

## Error handling

- `error_handling.on_document_error: continue|abort` — bad documents are quarantined to `output/_failed/` with an `.error.txt` and the batch continues.
- `error_handling.on_ocr_error: fallback_text|skip_page|fail` — on OCR outage, whatever digital text exists is used instead.
- `error_handling.on_figure_error: placeholder|omit|fail`.
- Transient API failures (429/5xx/timeouts) are retried with exponential backoff + jitter per `retry.*`.

## Repository layout

```
config/pipeline.yaml            full production configuration (documented inline)
src/mdx_pipeline/
  config.py                     pydantic models, ${ENV} interpolation, MDX__ overrides
  infra.py                      logging, retry, token-bucket rate limiter, disk cache
  routing.py                    page classification + image text-likelihood heuristic
  ocr/mistral_client.py         Mistral OCR client (both submission modes, caching)
  vision/describer.py           VLM figure describer (OpenAI-compatible / Mistral)
  render/markdown.py            element model + configurable Markdown renderer
  converters/pdf_hybrid.py      structure-aware PDF converter (registered over built-in)
  converters/image_ocr.py       standalone image converter
  pipeline.py                   batch engine (discovery, waves, quarantine, stats)
  cli.py                        `mdx run | one | routes`
tests/                          synthetic corpus + smoke tests
```
