"""Driver: python main.py [pdf_path] [-c config.yaml]"""
import argparse
import logging
import time

import yaml

from pdf_extractor import PDFExtractor


def main() -> None:
    ap = argparse.ArgumentParser(description="PDF -> structured Markdown")
    ap.add_argument("pdf", nargs="?", help="input PDF (overrides config)")
    ap.add_argument("-c", "--config", default="config.yaml")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    with open(args.config, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    pdf_path = args.pdf or config["paths"]["input_pdf"]
    t0 = time.perf_counter()
    page_image, page_text = PDFExtractor(config).extract(pdf_path)
    scanned = [n for n, img in page_image.items() if img is not None]
    print(f"Done in {time.perf_counter() - t0:.2f}s | "
          f"{len(page_text)} pages, {len(scanned)} scanned: {scanned}")


if __name__ == "__main__":
    main()
